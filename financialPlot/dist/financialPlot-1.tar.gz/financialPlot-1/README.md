FinancialPlot: financial statement visualization package

`from financialPlot import financialPlot`
